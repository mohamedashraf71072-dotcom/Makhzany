مخزني - مشروع أندرويد لبناء APK

مهم: هذا مشروع Android Studio وليس ملف APK جاهزًا. يحتاج Android SDK وGradle لبناء ملف التثبيت.

خطوات البناء على كمبيوتر:
1) فك ضغط MakhzanyAndroid.zip.
2) افتح مجلد Makhzany في Android Studio.
3) وافق على تثبيت Android SDK Platform 35 إذا طُلب منك، وانتظر Gradle Sync.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد الملف عادة في app/build/outputs/apk/debug/app-debug.apk.

التطبيق يحتوي صفحة HTML محلية مضمّنة داخل التطبيق، ويعمل دون إنترنت.
البيانات محفوظة في تخزين WebView على الجهاز. احتفظ بنسخة احتياطية من شاشة النسخ الاحتياطي داخل البرنامج.
